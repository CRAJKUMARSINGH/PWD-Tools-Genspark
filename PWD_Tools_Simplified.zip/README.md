# PWD Tools - Simplified Version

This is a simplified version of the PWD Tools application with a focus on the core dashboard and essential tools.

## Structure

- `pwd_main_landing.py` - Main application dashboard with colorful interface
- `run_pwd_tools.py` - Application launcher
- `START_PWD_TOOLS.bat` - Windows batch file to launch the application
- `core_requirements.txt` - Minimal requirements for the simplified version

## How to Run

1. Make sure you have Python installed (3.7 or higher)
2. Run the application using one of these methods:
   - Double-click `START_PWD_TOOLS.bat`
   - Run `python run_pwd_tools.py` in the terminal

## Features

- Colorful, user-friendly dashboard
- 6 essential tools for PWD operations
- Simple navigation
- Offline functionality

## Tools Included

1. Hindi Bill Note Generator
2. Stamp Duty Calculator
3. EMD Refund Processor
4. Delay Calculator
5. Financial Analysis
6. Online Bill Generator Link

## Color Scheme

The application uses a carefully designed color scheme:
- Header: Sea Green (#2E8B57)
- Tool buttons: Unique colors for each tool
- Background: Light blue (#f0f8ff)
- Welcome message: Light blue background (#E6F3FF)

This simplified version focuses on the core functionality while maintaining the beautiful interface.